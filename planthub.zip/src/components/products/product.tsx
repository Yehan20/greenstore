import React, { useEffect, useState } from 'react'
import { AiOutlineMinus, AiOutlinePlus } from 'react-icons/ai'
import { HiShoppingBag } from 'react-icons/hi'
import { useParams } from 'react-router-dom';
import { useAppDispatch } from '../../hooks/hooks';
import singleItem from '../../pages/itemtype/singleItem';
import { addCart, calculateTotal, fetchItem } from '../../reducers/cartSlice';
import { item } from '../../types/types';



const Product:React.FC<item>=({Name,src,price,type}) => {
    const [amount,setAmount]=useState(1);
    // adding to cart
    const dispatch = useAppDispatch()
    const { id } = useParams()
    useEffect(() => {
        dispatch(fetchItem(id as string))
        window.scrollTo(0,0)
      }, [])
    
    
    const handleClick = ()=>{
      dispatch(addCart({singleItem,amount}))
      dispatch(calculateTotal())
    }
  return (
    <>
       <div>
           <img  src={`http://${src}`} alt={Name} />
           </div>
           <div>
                <h3>{Name}</h3>
                <p><span>Rs: {price}</span> <span>Total Price {(price as number)*amount}</span></p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla quidem veniam corporis, minima quam magni dolor, beatae, quis omnis ad recusandae architecto non aspernatur unde tenetur iusto harum animi maiores.</p>
                <div>
                   <button disabled={amount<=1?true:false} aria-label="Decrease quantity Amount"   onClick={()=>setAmount(amount-1)}><AiOutlineMinus/></button>
                   <input min={1} type="number"  title='Decrease' onChange={(e)=>setAmount(parseInt(e.target.value))} value={amount} />
                   <button aria-label="Increase" title='Increase Amount' onClick={()=>setAmount(amount+1)}><AiOutlinePlus/></button>
                   <div>
                      <button onClick={handleClick}>Add to basket <HiShoppingBag/></button>
                   </div>
                </div>
                <p>Category: <b>{type}</b></p>
           </div>
    </>
  )
}

export default Product